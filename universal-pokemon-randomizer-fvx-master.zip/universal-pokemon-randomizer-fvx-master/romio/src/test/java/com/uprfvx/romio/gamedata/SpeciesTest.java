package com.uprfvx.romio.gamedata;

import com.uprfvx.romio.gamedata.basestats.BaseStats;
import com.uprfvx.romio.gamedata.basestats.Gen1BaseStats;
import com.uprfvx.romio.gamedata.basestats.ShedinjaBaseStats;
import com.uprfvx.romio.graphics.palettes.Color;
import com.uprfvx.romio.graphics.palettes.Palette;
import com.uprfvx.romio.graphics.palettes.SGBPaletteID;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class SpeciesTest {

    // === Setup / usable variables ==================

    // Having these objects like this (hardcoded a,b,c,d... instead of in some array or so)
    // might seem silly. It is! But this verbose mess up here comes in exchange for the
    // tests themselves being more readable/straight-forward.

    private static final int A_NUM = 1;
    private static final int B_NUM = 2;
    private static final int C_NUM = 3;
    private static final int D_NUM = 4;

    private Species a = new Species(A_NUM);
    private Species b = new Species(B_NUM);
    private Species c = new Species(C_NUM);
    private Species d = new Species(D_NUM);
    {
        a.setName("A");
        b.setName("B");
        c.setName("C");
        d.setName("D");
    }
    private Species aCopy = new Species(A_NUM);
    private Species bCopy = new Species(B_NUM);
    private Species cCopy = new Species(C_NUM);
    private Species dCopy = new Species(D_NUM);
    
    /**
     * Selects which Species objects may be used in this test.
     */
    private void use(Species... toUse) {
        if (!List.of(toUse).contains(a)) {
            a = null;
        } else if(!List.of(toUse).contains(b)) {
            b = null;
        } else if(!List.of(toUse).contains(c)) {
            c = null;
        } else if(!List.of(toUse).contains(d)) {
            d = null;
        } else if (!List.of(toUse).contains(aCopy)) {
            aCopy = null;
        } else if (!List.of(toUse).contains(bCopy)) {
            bCopy = null;
        } else if (!List.of(toUse).contains(cCopy)) {
            cCopy = null;
        } else if (!List.of(toUse).contains(dCopy)) {
            dCopy = null;
        }
    }

    /**
     * Applies {@link Species#transferAttributesToCopy(Species, Map)} to all
     * pairs of originals / copies that are used in this test, as per {@link #use(Species...)}.
     */
    private void transferAttributesToCopies() {
        Map<Species, Species> originalToCopy = new HashMap<>();
        if (a != null && aCopy != null) {
            originalToCopy.put(a, aCopy);
        }
        if (b != null && bCopy != null) {
            originalToCopy.put(b, bCopy);
        }
        if (c != null && cCopy != null) {
            originalToCopy.put(c, cCopy);
        }
        if (d != null && dCopy != null) {
            originalToCopy.put(d, dCopy);
        }
        for (Species original : originalToCopy.keySet()) {
            Species.transferAttributesToCopy(original, originalToCopy);
        }
    }

    // ==================================================

    @Test
    public void getBaseForme_OfBaseForme_ReturnsItself() {
        use(a);
        assertEquals(a, a.getBaseForme());
    }

    @Test
    public void getBaseForme_OfAltForme_ReturnsBaseForme() {
        use(a, b);
        a.addAltForme(1, b);
        assertEquals(a, b.getBaseForme());
    }

    @Test
    public void isBaseForme_OnUnmodifiedSpecies_ReturnsTrue() {
        assertTrue(new Species(0).isBaseForme());
    }

    @Test
    public void isBaseForme_OnSpeciesWithAltForme_ReturnsTrue() {
        use(a, b);
        a.addAltForme(1, b);
        assertTrue(a.isBaseForme());
    }

    @Test
    public void isBaseForme_OnAltForme_ReturnsFalse() {
        use(a, b);
        a.addAltForme(1, b);
        assertFalse(b.isBaseForme());
    }

    @Test
    public void setConceptualBaseForme_AlreadyHasConceptualBaseForme_ThrowsIllegalStateException() {
        use(a, b, c, d);
        a.addAltForme(1, b);
        a.addAltForme(2, c);
        a.addAltForme(3, d);
        d.setConceptualBaseForme(b);
        assertThrowsExactly(IllegalStateException.class,
                () -> d.setConceptualBaseForme(c));
    }

    @Test
    public void setConceptualBaseForme_OnBaseForme_ThrowsIllegalStateException() {
        use(a, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.setConceptualBaseForme(a));
    }

    @Test
    public void setConceptualBaseForme_ConceptualBaseFormeIsBaseForme_ThrowsIllegalArgumentException() {
        use(a, b);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalArgumentException.class,
                () -> b.setConceptualBaseForme(a));
    }

    @Test
    public void setConceptualBaseForme_ConceptualBaseFormeIsAltFormeOfAnotherSpecies_ThrowsIllegalStateException() {
        use(a, b, c, d);
        a.addAltForme(1, b);
        c.addAltForme(1, d);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.setConceptualBaseForme(d));
    }

    @Test
    public void addAltForme_FormeNumberIsUniqueAltFormeIsUnchanged_DoesNotThrow() {
        use(a, b);
        a.addAltForme(1, b);
    }

    @Test
    public void addAltForme_ToItself_ThrowsIllegalArgumentException() {
        use(a);
        assertThrowsExactly(IllegalArgumentException.class,
                () -> a.addAltForme(1, a));
    }

    @Test
    public void addAltForme_ToAltForme_ThrowsIllegalStateException() {
        use(a, b, c);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.addAltForme(2, c));
    }

    @Test
    public void addAltForme_FormeNumberIsZero_ThrowsIllegalStateException() {
        // IllegalState instead of IllegalArgument because internally it's the same check as
        // any other overlapping forme number.
        use(a, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> a.addAltForme(0, b));
    }

    @Test
    public void addAltForme_FormeNumberIsAlreadyUsed_ThrowsIllegalStateException() {
        use(a, b, c);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> a.addAltForme(1, c));
    }

    @Test
    public void addAltForme_AltFormeIsAltFormeOfAnotherSpecies_ThrowsIllegalStateException() {
        use(a, b, c);
        a.addAltForme(1, c);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.addAltForme(2, c));
    }

    @Test
    public void addCosmeticAltForme_ToAltForme_ThrowsIllegalStateException() {
        use(a, b);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.addCosmeticAltForme(2));
    }

    @Test
    public void addCosmeticAltForme_FormeNumberIsAlreadyUsed_ThrowsIllegalStateException() {
        use(a, b);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> a.addCosmeticAltForme(1));
    }

    @Test
    public void getForme_OfAltForme_ThrowsIllegalStateException() {
        use(a, b);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                () -> b.getForme(0));
    }

    @Test
    public void getForme_FormeNumberIsZero_ReturnsItself() {
        use(a);
        assertEquals(a, a.getForme(0));
    }

    @Test
    public void getForme_FormeNumberIsThatOfNonCosmeticForme_ReturnsThatForme() {
        use(a, b);
        a.addAltForme(1, b);
        assertEquals(b, a.getForme(1));
    }

    @Test
    public void getForme_FormeNumberIsThatOfCosmeticForme_ReturnsItself() {
        use(a);
        a.addCosmeticAltForme(1);
        assertEquals(a, a.getForme(1));
    }

    @Test
    public void getForme_FormeNumberIsUnassigned_ThrowsNoSuchElementException() {
        use(a);
        assertThrowsExactly(NoSuchElementException.class,
                () -> a.getForme(1));
    }

    @Test
    public void getAltFormes_NoAltFormesAssigned_ReturnsEmptySpeciesSet() {
        use(a);
        assertEquals(new SpeciesSet(), a.getAltFormes());
    }

    @Test
    public void getAltFormes_NonCosmeticAltFormesAssigned_ReturnsSpeciesSetWithThoseFormes() {
        use(a, b, c);
        a.addAltForme(1, b);
        a.addAltForme(2, c);
        assertEquals(new SpeciesSet(List.of(b, c)), a.getAltFormes());
    }

    @Test
    public void getAltFormes_OnlyCosmeticAltFormesAssigned_ReturnsEmptySpeciesSet() {
        use(a);
        a.addCosmeticAltForme(1);
        assertEquals(new SpeciesSet(), a.getAltFormes());
    }

    @Test
    public void getFormeNumber_OfBaseForme_ReturnsZero() {
        use(a);
        assertEquals(0, a.getFormeNumber());
    }

    @Test
    public void getFormeNumber_OfAltForme_ReturnsFormeNumberAssignedInSet() {
        use(a, b);
        a.addAltForme(1, b);
        assertEquals(1, b.getFormeNumber());
    }

    @Test
    public void setAlolan_OnBaseForme_ThrowsIllegalStateException() {
        use(a);
        assertThrowsExactly(IllegalStateException.class,
                a::setAlolan);
    }

    @Test
    public void setEssentiallyCosmetic_OnBaseForme_ThrowsIllegalStateException() {
        use(a);
        assertThrowsExactly(IllegalStateException.class,
                a::setEssentiallyCosmetic);
    }

    @Test
    public void setIgnoreCosmetic_OnBaseForme_ThrowsIllegalStateException() {
        use(a);
        assertThrowsExactly(IllegalStateException.class,
                a::setIgnoreCosmetic);
    }

    @Test
    public void setIgnoreCosmetic_OnNonEssentiallyCosmeticAltForme_ThrowsIllegalStateException() {
        use(a, b);
        a.addAltForme(1, b);
        assertThrowsExactly(IllegalStateException.class,
                b::setIgnoreCosmetic);
    }
    
    @Test
    public void transferAttributesToCopy_OriginalIsNull_ThrowsNullPointerException() {
        assertThrowsExactly(NullPointerException.class,
                () -> Species.transferAttributesToCopy(null, Map.of()));
    }

    @Test
    public void transferAttributesToCopy_OriginalToCopiesIsNull_ThrowsNullPointerException() {
        use(a);
        assertThrowsExactly(NullPointerException.class,
                () -> Species.transferAttributesToCopy(a, null));
    }

    @Test
    public void transferAttributesToCopy_CopyIsNotInOriginalToCopies_ThrowsIllegalArgumentException() {
        use(a);
        assertThrowsExactly(IllegalArgumentException.class,
                () -> Species.transferAttributesToCopy(a, Map.of()));
    }

    @Test
    public void transferAttributesToCopy_CopyHasDifferentNumber_ThrowsIllegalArgumentException() {
        use(a, b);
        Species aCopy = new Species(99);
        assertThrowsExactly(IllegalArgumentException.class,
                () -> Species.transferAttributesToCopy(a, Map.of(a, aCopy)));
    }
    
    @Test
    public void transferAttributesToCopy_CopyHasDifferentClass_ThrowsIllegalArgumentException() {
        // At the time of writing, we don't have any subclasses of Species.
        // There might be in the future, perhaps? Or perhaps not.
        // In any case there used to be a Gen1RomHandler subclass, and so this test was written.
        // Felt like a waste to erase it.
        // -- voliol 2026-06-22
        use(a, b);
        class SpeciesExtension extends Species {
            public SpeciesExtension(int number) {
                super(number);
            }
        }
        Species aCopy = new SpeciesExtension(A_NUM);
        assertThrowsExactly(IllegalArgumentException.class,
                () -> Species.transferAttributesToCopy(a, Map.of(a, aCopy)));
    }


    @Test
    public void transferAttributesToCopy_WithSimplestAttributes_TransfersAllAttributes() {
        // Simplest -> primitives and enums.
        // Items, BreedingInfo, EVYield get their own tests since they rely on full Objects,
        // even if these are simple ones.
        use(a, aCopy);
        a.setName("original");
        a.setGeneration(1);
        a.setPrimaryType(Type.NORMAL);
        a.setSecondaryType(null);
        a.setPrimaryType(Type.FIRE);
        a.setSecondaryType(Type.FIGHTING);
        a.setAbility1(2);
        a.setAbility2(3);
        a.setAbility3(4);
        a.setExpYield(5);
        a.setCatchRate(6);
        a.setGenderRatio(7);
        a.setCallRate(8);
        a.setGrowthCurve(ExpCurve.MEDIUM_FAST);

        transferAttributesToCopies();

        assertEquals("original", aCopy.getName());
        assertEquals(1, aCopy.getGeneration());
        assertEquals(Type.NORMAL, aCopy.getPrimaryType(true));
        assertNull(aCopy.getSecondaryType(true));
        assertEquals(Type.FIRE, aCopy.getPrimaryType(false));
        assertEquals(Type.FIGHTING, aCopy.getSecondaryType(false));
        assertEquals(2, aCopy.getAbility1());
        assertEquals(3, aCopy.getAbility2());
        assertEquals(4, aCopy.getAbility3());
        assertEquals(5, aCopy.getExpYield());
        assertEquals(6, aCopy.getCatchRate());
        assertEquals(7, aCopy.getGenderRatio());
        assertEquals(8, aCopy.getCallRate());
        assertEquals(ExpCurve.MEDIUM_FAST, aCopy.getGrowthCurve());
    }

    @Test
    public void transferAttributesToCopy_WithNormalBaseStats_TransfersBaseStats() {
        use(a, aCopy);
        a.setBaseStats(new BaseStats(
                1, 2, 3, 4, 5, 6
        ));

        transferAttributesToCopies();

        assertEquals(1, aCopy.getBaseStats().getHp());
        assertEquals(2, aCopy.getBaseStats().getAttack());
        assertEquals(3, aCopy.getBaseStats().getDefense());
        assertEquals(4, aCopy.getBaseStats().getSpatk());
        assertEquals(5, aCopy.getBaseStats().getSpdef());
        assertEquals(6, aCopy.getBaseStats().getSpeed());
        assertEquals(1 + 2 + 3 + 4 + 5 + 6, aCopy.getBST(true)); // the originalBST field
    }

    @Test
    public void transferAttributesToCopy_WithGen1BaseStats_TransfersBaseStats() {
        use(a, aCopy);
        a.setBaseStats(new Gen1BaseStats(
                1, 2, 3, 4, 5
        ));

        transferAttributesToCopies();

        assertInstanceOf(Gen1BaseStats.class, aCopy.getBaseStats());
        Gen1BaseStats aCopyBaseStats = (Gen1BaseStats) aCopy.getBaseStats();
        assertEquals(1, aCopyBaseStats.getHp());
        assertEquals(2, aCopyBaseStats.getAttack());
        assertEquals(3, aCopyBaseStats.getDefense());
        assertEquals(4, aCopyBaseStats.getSpeed());
        assertEquals(5, aCopyBaseStats.getSpecial());
    }

    @Test
    public void transferAttributesToCopy_WithShedinjaBaseStats_TransfersBaseStats() {
        use(a, aCopy);
        a.setBaseStats(new ShedinjaBaseStats(
                1, 2, 3, 4, 5
        ));

        transferAttributesToCopies();

        assertEquals(1, aCopy.getBaseStats().getAttack());
        assertEquals(2, aCopy.getBaseStats().getDefense());
        assertEquals(3, aCopy.getBaseStats().getSpatk());
        assertEquals(4, aCopy.getBaseStats().getSpdef());
        assertEquals(5, aCopy.getBaseStats().getSpeed());
    }


    @Test
    public void transferAttributesToCopy_WithGuaranteedHeldItem_TransfersGuaranteedHeldItem() {
        use(a, aCopy);
        Item guaranteedItem = new Item(1, "Guaranteed");
        a.setGuaranteedHeldItem(guaranteedItem);

        transferAttributesToCopies();

        assertEquals(guaranteedItem, aCopy.getGuaranteedHeldItem());
    }

    @Test
    public void transferAttributesToCopy_WithNonGuaranteedHeldItems_TransfersNonGuaranteedHeldItems() {
        use(a, aCopy);
        Item commonItem = new Item(1, "Common");
        Item rareItem = new Item(2, "Rare");
        Item darkGrassItem = new Item(3, "DarkGrass");
        a.setCommonHeldItem(commonItem);
        a.setRareHeldItem(rareItem);
        a.setDarkGrassHeldItem(darkGrassItem);

        transferAttributesToCopies();

        assertEquals(commonItem, aCopy.getCommonHeldItem());
        assertEquals(rareItem, aCopy.getRareHeldItem());
        assertEquals(darkGrassItem, aCopy.getDarkGrassHeldItem());
    }

    @Test
    public void transferAttributesToCopy_WithBreedingInfo_TransfersBreedingInfo() {
        use(a, aCopy);
        BreedingInfo breedingInfo = new BreedingInfo(EggGroup.FIELD, null, 1);
        a.setBreedingInfo(breedingInfo);

        transferAttributesToCopies();

        assertNotNull(aCopy.getBreedingInfo());
        assertEquals(EggGroup.FIELD, aCopy.getBreedingInfo().getPrimaryEggGroup());
        assertNull(aCopy.getBreedingInfo().getSecondaryEggGroup());
        assertEquals(1, aCopy.getBreedingInfo().getEggCycles());
    }

    @Test
    public void transferAttributesToCopy_WithEVYield_TransfersEVYield() {
        use(a, aCopy);
        EVYield evYield = new EVYield(0, 1, 2, 0, 1, 2);
        a.setEVYield(evYield);

        transferAttributesToCopies();

        assertNotNull(aCopy.getEVYield());
        assertEquals(a.getEVYield(), aCopy.getEVYield());
    }

    @Test
    public void transferAttributesToCopy_WithPalettes_TransfersPalettes() {
        use(a, aCopy);
        a.setPaletteID(SGBPaletteID.MEWMON);
        a.setNormalPalette(new Palette(1, Color.BLACK));
        a.setShinyPalette(new Palette(1, Color.WHITE));

        transferAttributesToCopies();

        assertEquals(SGBPaletteID.MEWMON, aCopy.getPaletteID());
        assertNotNull(aCopy.getNormalPalette());
        assertEquals(new Palette(1, Color.BLACK), aCopy.getNormalPalette());
        assertNotNull(aCopy.getShinyPalette());
        assertEquals(new Palette(1, Color.WHITE), aCopy.getShinyPalette());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_FormesGetCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);

        transferAttributesToCopies();

        // important to not assertEquals here, since the copies equal the originals
        // (since equality is based on number only)
        assertSame(aCopy, aCopy.getForme(0));
        assertSame(bCopy, aCopy.getForme(1));
    }

    @Test
    public void transferAttributesToCopy_WithFormes_CosmeticFormesGetCopied() {
        use(a, aCopy);
        a.addCosmeticAltForme(1);

        transferAttributesToCopies();

        assertEquals(List.of(0, 1), aCopy.getCosmeticFormeNumbers());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_IgnoreCosmeticFormesGetCopied() {
        use(a, aCopy);
        a.addCosmeticAltForme(1);
        a.setIgnoreCosmeticAltForme(1);

        transferAttributesToCopies();

        assertEquals(List.of(1), aCopy.getIgnoreCosmeticFormeNumbers());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_FormeNumberGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);

        transferAttributesToCopies();

        assertEquals(1, bCopy.getFormeNumber());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_FormeSuffixGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);
        b.setFormeSuffix("Suffix");

        transferAttributesToCopies();

        assertEquals("Suffix", bCopy.getFormeSuffix());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_BaseFormeGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);

        transferAttributesToCopies();

        assertSame(aCopy, bCopy.getBaseForme());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_ConceptualBaseFormeGetsCopied() {
        use(a, b, c, aCopy, bCopy, cCopy);
        a.addAltForme(1, b);
        a.addAltForme(2, c);
        c.setConceptualBaseForme(b);

        transferAttributesToCopies();

        assertSame(bCopy, cCopy.getConceptualBaseForme());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_MegaEvolutionAttributesGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);
        Item megaEvolutionItem = new Item(1, "dummy");
        b.setMegaEvolution(megaEvolutionItem);

        transferAttributesToCopies();

        assertTrue(bCopy.isMegaEvolution());
        assertEquals(megaEvolutionItem, bCopy.getMegaEvolutionItem());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_AlolanGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);
        b.setAlolan();

        transferAttributesToCopies();

        assertTrue(bCopy.isAlolan());
    }

    @Test
    public void transferAttributesToCopy_WithFormes_EssentiallyCosmeticGetsCopied() {
        use(a, b, aCopy, bCopy);
        a.addAltForme(1, b);
        b.setEssentiallyCosmetic();

        transferAttributesToCopies();

        assertTrue(bCopy.isEssentiallyCosmetic());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_MatchingEvolutionsFromAndToAreSame() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertSame(aCopy.getEvolutionsFrom().getFirst(), bCopy.getEvolutionsTo().getFirst());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_FromReferenceGetCopied() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertSame(aCopy, aCopy.getEvolutionsFrom().getFirst().getFrom());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_ToReferenceGetCopied() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertSame(bCopy, aCopy.getEvolutionsFrom().getFirst().getTo());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_EvolutionTypeGetsCopied() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertEquals(EvolutionType.LEVEL, aCopy.getEvolutionsFrom().getFirst().getType());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_EvolutionExtraInfoGetsCopied() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertEquals(1, aCopy.getEvolutionsFrom().getFirst().getExtraInfo());
    }

    @Test
    public void transferAttributesToCopy_WithEvolutions_EstimatedEvoLvlGetsCopied() {
        use(a, b, aCopy, bCopy);
        Evolution evolution = new Evolution(a, b, EvolutionType.LEVEL, 1, 2);
        a.getEvolutionsFrom().add(evolution);
        b.getEvolutionsTo().add(evolution);

        transferAttributesToCopies();

        assertEquals(2, aCopy.getEvolutionsFrom().getFirst().getEstimatedEvoLvl());
    }
}
