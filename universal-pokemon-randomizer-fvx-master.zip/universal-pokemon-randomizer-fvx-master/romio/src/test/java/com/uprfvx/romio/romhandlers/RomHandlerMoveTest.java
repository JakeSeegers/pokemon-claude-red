package com.uprfvx.romio.romhandlers;

import com.uprfvx.romio.constants.MoveIDs;
import com.uprfvx.romio.gamedata.Move;
import com.uprfvx.romio.gamedata.MoveLearnt;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

public class RomHandlerMoveTest extends RomHandlerTest {

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void movesAreNotEmpty(String romName) {
        loadROM(romName);
        System.out.println(romHandler.getMoves());
        assertFalse(romHandler.getMoves().isEmpty());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void firstMoveIsNull(String romName) {
        loadROM(romName);
        assertNull(romHandler.getMoves().get(0));
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void allMovesHaveNonBlankNames(String romName) {
        loadROM(romName);
        System.out.println(romHandler.getMoves());
        for (Move m : romHandler.getMoves()) {
            if (m != null) {
                assertFalse(m.name.replaceAll("\\s", "").isEmpty());
            }
        }
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void moveNamesDoNotChangeWithLoadAndSave(String romName) {
        loadROM(romName);
        List<String> before = romHandler.getMoves().stream().filter(Objects::nonNull).map(m -> m.name).toList();
        romHandler.saveMoves();
        romHandler.loadMoves();
        List<String> after = romHandler.getMoves().stream().filter(Objects::nonNull).map(m -> m.name).toList();
        assertEquals(before, after);
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void movesLearntDoNotChangeWithGetAndSet(String romName) {
        loadROM(romName);
        Map<Integer, List<MoveLearnt>> movesLearnt = romHandler.getMovesLearnt();
        Map<Integer, List<MoveLearnt>> before = new HashMap<>(movesLearnt);
        romHandler.setMovesLearnt(movesLearnt);
        assertEquals(before, romHandler.getMovesLearnt());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void movesLearntDoNotChangeWithLoadAndSave(String romName) {
        assumeTrue(isGBGame(romName));
        loadROM(romName);
        AbstractGBRomHandler gbRomHandler = (AbstractGBRomHandler) romHandler;
        Map<Integer, List<MoveLearnt>> movesLearnt = romHandler.getMovesLearnt();
        Map<Integer, List<MoveLearnt>> before = new HashMap<>(movesLearnt);
        romHandler.setMovesLearnt(movesLearnt);
        gbRomHandler.saveSpeciesStats();
        gbRomHandler.loadSpeciesStats();
        assertEquals(before, romHandler.getMovesLearnt());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void eggMovesDoNotChangeWithGetAndSet(String romName) {
        assumeTrue(getGenerationNumberOf(romName) != 1);
        loadROM(romName);
        Map<Integer, List<Integer>> eggMoves = romHandler.getEggMoves();
        Map<Integer, List<Integer>> before = new HashMap<>(eggMoves);
        romHandler.setEggMoves(eggMoves);
        assertEquals(before, romHandler.getEggMoves());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void tmMovesDoNotChangeWithGetAndSet(String romName) {
        loadROM(romName);
        List<Integer> tmMoves = romHandler.getTMMoves();
        List<Integer> before = new ArrayList<>(tmMoves);
        romHandler.setTMMoves(tmMoves);
        assertEquals(before, romHandler.getTMMoves());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void moveTutorMovesDoNotChangeWithGetAndSet(String romName) {
        loadROM(romName);
        assumeTrue(romHandler.hasMoveTutors());
        List<Integer> moveTutorMoves = romHandler.getMoveTutorMoves();
        List<Integer> before = new ArrayList<>(moveTutorMoves);
        romHandler.setMoveTutorMoves(moveTutorMoves);
        assertEquals(before, romHandler.getMoveTutorMoves());
    }

    @ParameterizedTest
    @MethodSource("getRomNames")
    public void moveTutorMovesCanBeChangedWithGetAndSet(String romName) {
        loadROM(romName);
        assumeTrue(romHandler.hasMoveTutors());

        List<Integer> moveTutorMoves = new ArrayList<>(romHandler.getMoveTutorMoves());
        // struggle is used because we don't expect it in the unmodified ROM.
        Collections.fill(moveTutorMoves, MoveIDs.struggle);
        romHandler.setMoveTutorMoves(moveTutorMoves);

        List<Move> moves = romHandler.getMoves();
        int i = 0;
        for (int moveID : romHandler.getMoveTutorMoves()) {
            System.out.println("Move tutor #" + i + ": " + moves.get(moveID));
            assertEquals(MoveIDs.struggle, moveID);
        }
    }

}
