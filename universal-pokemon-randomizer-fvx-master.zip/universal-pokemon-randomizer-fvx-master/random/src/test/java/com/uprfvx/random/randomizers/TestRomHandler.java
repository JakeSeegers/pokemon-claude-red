package com.uprfvx.random.randomizers;

import com.uprfvx.romio.MiscTweak;
import com.uprfvx.romio.gamedata.*;
import com.uprfvx.romio.graphics.packs.CustomPlayerGraphics;
import com.uprfvx.romio.romhandlers.AbstractRomHandler;
import com.uprfvx.romio.romhandlers.PokemonImageGetter;
import com.uprfvx.romio.romhandlers.RomHandler;
import com.uprfvx.romio.romhandlers.romentries.RomEntry;
import com.uprfvx.romio.services.RestrictedSpeciesService;
import com.uprfvx.romio.services.TypeService;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * A special "dummy" romHandler which copies data from an existing romHandler.
 *
 */
public class TestRomHandler extends AbstractRomHandler {

    /**
     * Used for methods which could be supported by the TestRomHandler, but aren't implemented (yet).
     * Compare with plain {@link UnsupportedOperationException}, which is used in this class to mean
     * "this fundamentally doesn't work with (this) TestRomHandler".
     */
    private static class NotImplementedException extends UnsupportedOperationException {
        public NotImplementedException() {
            super();
        }
    }

    //Species
    private final SpeciesSet originalSpeciesInclFormes;
    private SpeciesSet testSpeciesInclFormes = null;
    private SpeciesSet testSpeciesNoFormes = null;
    Map<Species, Species> originalToTest = null;
    private SpeciesSet testAltFormes = null;
    private final SpeciesSet originalIrregularFormes;
    private SpeciesSet testIrregularFormes = null;
    private RestrictedSpeciesService testRSS = null;
    private List<Species> testSpeciesInOrder = null;
    private List<Species> testSpeciesInclFormesInOrder = null;

    //Abilities
    private final int abilitiesPerSpecies;

    //Moves
    private final List<Move> originalMoves;
    private List<Move> testMoves;
    private final Map<Integer, List<MoveLearnt>> originalMovesLearnt;
    private Map<Integer, List<MoveLearnt>> testMovesLearnt;
    private final Map<Integer, List<Integer>> originalEggMoves;
    private Map<Integer, List<Integer>> testEggMoves;
    private final int maxMoveNameLength;

    // TMs/HMs/Tutors
    private final List<Integer> originalTMMoves;
    private List<Integer> testTMMoves;
    private final List<Integer> hmMoves;
    private final boolean hasMoveTutors;
    private final List<Integer> originalMoveTutorMoves;
    private List<Integer> testMoveTutorMoves;
    private final Map<Species, boolean[]> originalTMHMCompatibility;
    private Map<Species, boolean[]> testTMHMCompatibility;
    private final Map<Species, boolean[]> originalMoveTutorCompatibility;
    private Map<Species, boolean[]> testMoveTutorCompatibility;

    //Evolutions
    private final boolean altFormesCanHaveDifferentEvolutions;

    //Encounters (wild)
    private final List<EncounterArea> originalEncounters;
    List<EncounterArea> testEncounters = null;
    private final boolean hasTimeBasedEncounters;
    private final boolean hasWildAltFormes;
    private final SpeciesSet originalBannedForWild;

    //Statics
    private final List<StaticEncounter> originalStatics;
    private List<StaticEncounter> testStatics = null;
    private final boolean canChangeStaticPokemon;
    private final boolean hasStaticAltFormes;
    private final SpeciesSet originalBannedForStatics;
    private final boolean forceSwapStaticMegaEvos;
    private final List<Integer> mainGameLegendaries;

    //Totems
    private final boolean hasTotemPokemon;
    private final List<TotemPokemon> originalTotems;
    private List<TotemPokemon> testTotems = null;

    //TMs/HMs
    private final boolean originalIsTMsReusable;
    private boolean testIsTMsReusable;
    private final boolean canTMsBeHeld;

    //Types
    private final TypeTable originalTypeTable;
    private TypeTable testTypeTable = null;
    private final boolean hasTypeEffectivenessSupport;

    //ROM identifiers
    private final int generation;
    private final boolean isYellow;
    private final boolean isORAS;
    private final boolean isUSUM;
    private final int romType;

    //Misc tweaks
    private final int miscTweaksAvailable;

    //Starters
    private final List<Species> originalStarters;
    private List<Species> testStarters = null;
    private final boolean hasStarterAltFormes;

    //Items
    private final List<Item> items;
    private final Set<Item> originalAllowedItems;
    private final Set<Item> evolutionItems;
    private final Set<Item> xItems;
    private final Set<Item> regularShopItems;
    private final Set<Item> opShopItems;
    private final Set<Item> uniqueNoSellItems;

    //Field Items
    private final Set<Item> requiredFieldTMs;
    private final List<Item> originalFieldItems;
    private List<Item> testFieldItems;

    //Pickup Items
    private final List<PickupItem> originalPickupItems;
    private List<PickupItem> testPickupItems;

    //Shops
    private final List<Shop> originalShops;
    private List<Shop> testShops;

    //Trainers
    private final SpeciesSet originalBannedForTrainers;
    private SpeciesSet testBannedForTrainers = null;
    private final List<Trainer> originalTrainers;
    private List<Trainer> testTrainers = null;
    private final List<Integer> mainPlaythroughTrainers;
    private final List<Integer> eliteFourTrainers;
    private final List<Integer> challengeModeEliteFourTrainers;
    private final Map<String, Type> gymAndEliteTypeThemes;
    private final boolean trainerPokemonAlwaysUseAbility1;
    private final boolean trainerPokemonUseBaseFormeAbilities;
    private final boolean canGiveCustomMovesetsToBossTrainers;
    private final boolean canGiveCustomMovesetsToImportantTrainers;
    private final boolean canGiveCustomMovesetsToRegularTrainers;
    private final boolean canAddPokemonToBossTrainers;
    private final boolean canAddPokemonToImportantTrainers;
    private final boolean canAddPokemonToRegularTrainers;
    private int highestEvoLvl = 0;

    //Palettes
    private final boolean hasPokemonPaletteSupport;
    private final String paletteFilesID;

    /**
     * Given a loaded RomHandler, creates a mockup TestRomHandler by extracting the data from it.
     * @param mockupOf A loaded RomHandler to create a mockup of.
     */
    public TestRomHandler(RomHandler mockupOf) {
        originalTypeTable = new TypeTable(mockupOf.getTypeTable());
        originalSpeciesInclFormes = SpeciesSet.unmodifiable(mockupOf.getSpeciesInclFormes());
        originalEncounters = Collections.unmodifiableList(mockupOf.getEncounters(true));
        originalIrregularFormes = SpeciesSet.unmodifiable(mockupOf.getIrregularFormes());

        abilitiesPerSpecies = mockupOf.abilitiesPerSpecies();

        originalMoves = Collections.unmodifiableList(mockupOf.getMoves());
        originalMovesLearnt = Collections.unmodifiableMap(mockupOf.getMovesLearnt());
        originalEggMoves = Collections.unmodifiableMap(mockupOf.getEggMoves());
        maxMoveNameLength = mockupOf.getMaxMoveNameLength();

        originalTMMoves = Collections.unmodifiableList(mockupOf.getTMMoves());
        hmMoves = Collections.unmodifiableList(mockupOf.getHMMoves());
        hasMoveTutors = mockupOf.hasMoveTutors();
        originalMoveTutorMoves = hasMoveTutors() ?
                Collections.unmodifiableList(mockupOf.getMoveTutorMoves()) :
                Collections.emptyList();
        originalTMHMCompatibility = Collections.unmodifiableMap(mockupOf.getTMHMCompatibility());
        originalMoveTutorCompatibility = hasMoveTutors ?
                Collections.unmodifiableMap(mockupOf.getMoveTutorCompatibility()) :
                Collections.emptyMap();

        altFormesCanHaveDifferentEvolutions = mockupOf.altFormesCanHaveDifferentEvolutions();

        hasTimeBasedEncounters = mockupOf.hasTimeBasedEncounters();
        hasWildAltFormes = mockupOf.hasWildAltFormes();
        originalBannedForWild = SpeciesSet.unmodifiable(mockupOf.getBannedForWildEncounters());

        originalStatics = Collections.unmodifiableList(mockupOf.getStaticPokemon());
        canChangeStaticPokemon = mockupOf.canChangeStaticPokemon();
        hasStaticAltFormes = mockupOf.hasStaticAltFormes();
        originalBannedForStatics = SpeciesSet.unmodifiable(mockupOf.getBannedForStaticPokemon());
        forceSwapStaticMegaEvos = mockupOf.forceSwapStaticMegaEvos();
        if(mockupOf.hasMainGameLegendaries()) {
            mainGameLegendaries = Collections.unmodifiableList(mockupOf.getMainGameLegendaries());
        } else {
            mainGameLegendaries = Collections.unmodifiableList(new ArrayList<>());
        }

        hasTotemPokemon = mockupOf.hasTotemPokemon();
        originalTotems = Collections.unmodifiableList(mockupOf.getTotemPokemon());

        originalIsTMsReusable = mockupOf.isTMsReusable();
        canTMsBeHeld = mockupOf.canTMsBeHeld();

        hasTypeEffectivenessSupport = mockupOf.hasTypeEffectivenessSupport();

        generation = mockupOf.generationOfPokemon();
        romType = mockupOf.getROMType();
        isYellow = mockupOf.isYellow();
        isORAS = mockupOf.isORAS();
        isUSUM = mockupOf.isUSUM();

        miscTweaksAvailable = mockupOf.miscTweaksAvailable();

        originalStarters = Collections.unmodifiableList(mockupOf.getStarters());
        hasStarterAltFormes = mockupOf.hasStarterAltFormes();

        items = Collections.unmodifiableList(mockupOf.getItems());
        originalAllowedItems = items.stream().filter(Objects::nonNull).filter(Item::isAllowed).collect(Collectors.toSet());
        evolutionItems = Collections.unmodifiableSet(mockupOf.getEvolutionItems());
        xItems = Collections.unmodifiableSet(mockupOf.getXItems());
        regularShopItems = Collections.unmodifiableSet(mockupOf.getRegularShopItems());
        opShopItems = Collections.unmodifiableSet(mockupOf.getOPShopItems());
        uniqueNoSellItems = Collections.unmodifiableSet(mockupOf.getMegaStones());

        requiredFieldTMs = Collections.unmodifiableSet(mockupOf.getRequiredFieldTMs());
        originalFieldItems = Collections.unmodifiableList(mockupOf.getFieldItems());

        originalPickupItems = Collections.unmodifiableList(mockupOf.getPickupItems());

        originalShops = Collections.unmodifiableList(mockupOf.getShops());

        originalBannedForTrainers = SpeciesSet.unmodifiable(mockupOf.getBannedFormesForTrainerPokemon());
        originalTrainers = Collections.unmodifiableList(mockupOf.getTrainers());
        mainPlaythroughTrainers = Collections.unmodifiableList(mockupOf.getMainPlaythroughTrainers());
        eliteFourTrainers = Collections.unmodifiableList(mockupOf.getEliteFourTrainers(false));
        challengeModeEliteFourTrainers = Collections.unmodifiableList(mockupOf.getEliteFourTrainers(true));
        gymAndEliteTypeThemes = Collections.unmodifiableMap(mockupOf.getGymAndEliteTypeThemes());
        trainerPokemonAlwaysUseAbility1 = mockupOf.isTrainerPokemonAlwaysUseAbility1();
        trainerPokemonUseBaseFormeAbilities = mockupOf.isTrainerPokemonUseBaseFormeAbilities();
        canGiveCustomMovesetsToBossTrainers = mockupOf.canGiveCustomMovesetsToBossTrainers();
        canGiveCustomMovesetsToImportantTrainers = mockupOf.canGiveCustomMovesetsToImportantTrainers();
        canGiveCustomMovesetsToRegularTrainers = mockupOf.canGiveCustomMovesetsToRegularTrainers();
        canAddPokemonToBossTrainers = mockupOf.canAddPokemonToBossTrainers();
        canAddPokemonToImportantTrainers = mockupOf.canAddPokemonToImportantTrainers();
        canAddPokemonToRegularTrainers = mockupOf.canAddPokemonToRegularTrainers();

        hasPokemonPaletteSupport = mockupOf.hasPokemonPaletteSupport();
        if (generation >= 3 && generation <= 5) {
            paletteFilesID = mockupOf.getPaletteFilesID();
        } else {
            paletteFilesID = null;
        }

        perfectAccuracy = mockupOf.getPerfectAccuracy();
        highestEvoLvl = mockupOf.getHighestEvoLvl();

        if (mockupOf.getResourceLifetime() != ResourceLifetime.NONE) {
            try {
                mockupOf.closeResources();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * Prepares for testing by making a deep copy of all Species,
     * which are passed by reference and therefore cannot otherwise be reset. <br>
     * Other test data is copied as needed.
     */
    public void prepare() {
        testSpeciesInclFormes = deepCopySpeciesSet(originalSpeciesInclFormes);
        testSpeciesInclFormes.forEach(Species::saveOriginalData);
    }

    /**
     * Resets all test data, mostly by simply dropping it.
     */
    public void reset() {
        testSpeciesInclFormes = null;
        testSpeciesNoFormes = null;
        originalToTest = null;
        testAltFormes = null;
        testIrregularFormes = null;
        testRSS = null;
        testSpeciesInOrder = null;
        testSpeciesInclFormesInOrder = null;

        testMoves = null;
        testMovesLearnt = null;
        testEggMoves = null;

        testTMMoves = null;
        testMoveTutorMoves = null;
        testTMHMCompatibility = null;
        testMoveTutorCompatibility = null;

        testEncounters = null;

        testStatics = null;
        testTotems = null;

        testIsTMsReusable = originalIsTMsReusable;

        testTypeTable = null;

        testStarters = null;

        // Items are passed around by reference a lot, but as we only expect their "allowed" attribute
        // to change, we can (and do) just reset that.
        for (Item item : items) {
            if (item != null) {
                item.setAllowed(originalAllowedItems.contains(item));
            }
        }

        testFieldItems = null;

        testShops = null;

        testBannedForTrainers = null;
        testTrainers = null;
    }

    /**
     * Deep copies the set of all Species in the game.
     * When finished, all Species should contain the same data, but have no references to
     * the original set.
     * @param originalSet The set of Species to deep-copy.
     * @return A copy of each of the Species given, with no
     */
    private SpeciesSet deepCopySpeciesSet(SpeciesSet originalSet) {
        SpeciesSet newSet = new SpeciesSet();
        originalToTest = new HashMap<>();
        // We need to create empty copies of all Species before transferring/copying traits,
        // otherwise species relations can't be copied.
        for (Species orig : originalSet) {
            Species copy = new Species(orig.getNumber());
            newSet.add(copy);
            originalToTest.put(orig, copy);
        }
        for (Species orig : originalSet) {
            Species.transferAttributesToCopy(orig, originalToTest);
        }

        // And these can be populated once the copy process is done
        testAltFormes = SpeciesSet.unmodifiable(new SpeciesSet(newSet).filter(pk -> !pk.isBaseForme()));
        testIrregularFormes =  SpeciesSet.unmodifiable(originalIrregularFormes.stream().map(originalToTest::get).toList());

        return SpeciesSet.unmodifiable(newSet);
    }

    /**
     * Given a SpeciesSet, creates a new SpeciesSet containing the copy corresponding to each Species in the set.
     * @param original The SpeciesSet to copy.
     * @return A new SpeciesSet with the corresponding copy for each Species in the original.
     */
    private SpeciesSet copySpeciesSet(SpeciesSet original) {
        SpeciesSet copy = new SpeciesSet();
        for(Species origSpec : original) {
            copy.add(originalToTest.get(origSpec));
        }
        return copy;
    }

    /**
     * Given a List of EncounterAreas, copies them such that each Species in the original Encounters
     * is replaced by its copied test version.
     * @param originalEncounters The List of EncounterAreas to copy.
     * @return A new List of new EncounterAreas which are copies of the given ones.
     */
    private List<EncounterArea> deepCopyEncounters(List<EncounterArea> originalEncounters) {
        List<EncounterArea> copiedEncounters = new ArrayList<>();
        for(EncounterArea originalArea : originalEncounters) {
            EncounterArea copiedArea = new EncounterArea();
            copiedArea.setRate(originalArea.getRate());
            copiedArea.banAllSpecies(copySpeciesSet(originalArea.getBannedSpecies()));
            copiedArea.setIdentifiers(originalArea.getDisplayName(), originalArea.getMapIndex(),
                    originalArea.getEncounterType(), originalArea.getLocationTag());
            copiedArea.setPostGame(originalArea.isPostGame());
            copiedArea.setPartiallyPostGameCutoff(originalArea.getPartiallyPostGameCutoff());
            copiedArea.setForceMultipleSpecies(originalArea.isForceMultipleSpecies());

            for(Encounter origEnc : originalArea) {
                Encounter copyEnc = new Encounter(originalToTest.get(origEnc.getSpecies().getBaseForme()), origEnc.getLevel());
                copyEnc.setMaxLevel(origEnc.getMaxLevel());
                if (origEnc.getSpeciesHolder().isAltFormeAllowed()) {
                    copyEnc.getSpeciesHolder().setAltFormeAllowed();
                    copyEnc.getSpeciesHolder().setFormeNumber(origEnc.getSpeciesHolder().getFormeNumber());
                }
                copyEnc.setSOS(origEnc.isSOS());
                copyEnc.setSosType(origEnc.getSosType());

                copiedArea.add(copyEnc);
            }

            copiedEncounters.add(copiedArea);
        }

        return copiedEncounters;
    }

    /**
     * Given a List of {@link StaticEncounter}s, copies them such that each Species in the original
     * is replaced by its copied test version.
     * @param originalStatics The List of StaticEncounters to copy.
     * @return A new List of new StaticEncounters which are copies of the given ones.
     */
    private List<StaticEncounter> deepCopyStatics(List<StaticEncounter> originalStatics) {
        List<StaticEncounter> copiedStatics = new ArrayList<>();
        for(StaticEncounter orig : originalStatics) {
            StaticEncounter copy = new StaticEncounter(orig);
            Species spec = originalToTest.get(orig.getSpecies());
            copy.getSpeciesHolder().setSpecies(spec);
            for(StaticEncounter linked : copy.getLinkedEncounters()) {
                linked.getSpeciesHolder().setSpecies(spec);
            }
            copiedStatics.add(copy);
        }
        return copiedStatics;
    }

    /**
     * Given a List of {@link TotemPokemon}s, copies them such that each Species in the original
     * is replaced by its copied test version.
     * @param originalTotems The List of TotemPokemon to copy.
     * @return A new List of new TotemPokemon which are copies of the given ones.
     */
    private List<TotemPokemon> deepCopyTotems(List<TotemPokemon> originalTotems) {
        List<TotemPokemon> copiedTotems = new ArrayList<>();
        for(TotemPokemon orig : originalTotems) {
            TotemPokemon copy = new TotemPokemon(orig);
            Species spec = originalToTest.get(orig.getSpecies());
            copy.getSpeciesHolder().setSpecies(spec);
            for (StaticEncounter linked : copy.getLinkedEncounters()) {
                linked.getSpeciesHolder().setSpecies(spec);
            }
            for (StaticEncounter ally : copy.getAllies().values()) {
                Species allySpec = originalToTest.get(ally.getSpecies());
                ally.getSpeciesHolder().setSpecies(allySpec);
            }
            copiedTotems.add(copy);
        }
        return copiedTotems;
    }


    /**
     * Given a List of {@link Trainer}s, copies them such that each Species in the original
     * is replaced by its copied test version.
     * @param originalTrainers The List of Trainers to copy.
     * @return A new List of Trainers which are copies of the given one.
     */
    private List<Trainer> deepCopyTrainers(List<Trainer> originalTrainers) {
        List<Trainer> copiedTrainers = new ArrayList<>();
        for(Trainer original : originalTrainers) {
            Trainer copy = new Trainer(original);
            for(TrainerPokemon tp : copy.getPokemon()) {
                tp.getSpeciesHolder().setSpecies(originalToTest.get(tp.getSpecies()));
            }
            copiedTrainers.add(copy);
        }

        return copiedTrainers;
    }

    /**
     * Given a {@link List} of {@link Move}s, copies each.
     * @param originalMoves The List of Moves to copy.
     * @return A new List of Moves containing a copy of each move.
     */
    private List<Move> deepCopyMoves(List<Move> originalMoves) {
        List<Move> copiedMoves = new ArrayList<>();
        for(Move original : originalMoves) {
            if(original == null) {
                copiedMoves.add(null);
                //some games start the list with a null move so they start at 1 instead of zero
                //(weirdly, it's not all games)
            } else {
                Move copy = new Move(original);
                copiedMoves.add(copy);
            }
        }
        return copiedMoves;
    }

    @Override
    public boolean loadRom(String filename) {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public void loadSpeciesStats() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean saveRom(String filename, long seed, boolean saveAsDirectory) {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public void loadTrainerClasses() {

    }

    @Override
    public void saveTrainerClasses() {

    }

    @Override
    public void loadTrainers() {

    }

    @Override
    public void saveTrainers() {

    }

    @Override
    public void loadMoves() {

    }

    @Override
    public void saveMoves() {

    }

    @Override
    public void saveSpeciesStats() {

    }

    @Override
    protected boolean saveRomFile(String filename, long seed) {
        return false;
    }

    @Override
    protected boolean saveRomDirectory(String filename) {
        return false;
    }

    @Override
    protected RomEntry getRomEntry() {
        return null;
    }

    @Override
    public String loadedFilename() {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public boolean hasGameUpdateLoaded() {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public boolean loadGameUpdate(String filename) {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public void removeGameUpdate() {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public String getGameUpdateVersion() {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public void printRomDiagnostics(PrintStream logStream) {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public boolean isRomValid(PrintStream logStream) {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public List<Species> getSpecies() {
        if(testSpeciesInOrder == null) {
            testSpeciesInOrder = new ArrayList<>(getSpeciesSet());
            testSpeciesInOrder.sort(Comparator.comparingInt(Species::getNumber)); //ok that's some sleek syntax. gj java.
            testSpeciesInOrder.addFirst(null); // and this is less sleek haha, O(#numPokemon)
        }
        return testSpeciesInOrder;
    }

    @Override
    public List<Species> getSpeciesInclFormes() {
        if(testSpeciesInclFormesInOrder == null) {
            testSpeciesInclFormesInOrder = new ArrayList<>(getSpeciesSetInclFormes());
            testSpeciesInclFormesInOrder.sort(Comparator.comparingInt(Species::getNumber)); //ok that's some sleek syntax. gj java.
            testSpeciesInclFormesInOrder.addFirst(null); // and this is less sleek haha, O(#numPokemon)
        }
        return testSpeciesInclFormesInOrder;
    }

    @Override
    public SpeciesSet getAltFormes() {
        return testAltFormes;
    }

    @Override
    public SpeciesSet getSpeciesSet() {
        if(testSpeciesNoFormes == null) {
            testSpeciesNoFormes = SpeciesSet.unmodifiable(testSpeciesInclFormes.filter(Species::isBaseForme));
        }

        return testSpeciesNoFormes;
    }

    @Override
    public SpeciesSet getSpeciesSetInclFormes() {
        return testSpeciesInclFormes;
    }

    @Override
    public SpeciesSet getIrregularFormes() {
        return testIrregularFormes;
    }

    @Override
    public RestrictedSpeciesService getRestrictedSpeciesService() {
        if(testRSS == null) {
            testRSS = new RestrictedSpeciesService(this);
            testRSS.setRestrictions(new GenRestrictions());
        }
        return testRSS;
    }

    @Override
    public void removeEvosForPokemonPool() {
        throw new NotImplementedException();
        //Why is THIS in RomHandler, either???
    }

    @Override
    public List<Species> getStarters() {
        if(testStarters == null) {
            testStarters = new ArrayList<>();
            for(Species origStarter : originalStarters) {
                testStarters.add(originalToTest.get(origStarter));
            }
        }

        return testStarters;
    }

    @Override
    public boolean setStarters(List<Species> newStarters) {
        if(newStarters.size() != originalStarters.size()) {
            throw new IllegalArgumentException("Starter list is wrong size!");
        }

        testStarters = newStarters;
        return true;
    }

    @Override
    public boolean hasStarterAltFormes() {
        return hasStarterAltFormes;
    }

    @Override
    public int starterCount() {
        return originalStarters.size();
    }

    @Override
    public boolean hasStarterTypeTriangleSupport() {
        return originalStarters.size() % 3 == 0;
    }

    @Override
    public boolean supportsStarterHeldItems() {
        throw new NotImplementedException();
    }

    @Override
    public List<Item> getStarterHeldItems() {
        throw new NotImplementedException();
    }

    @Override
    public void setStarterHeldItems(List<Item> items) {
        throw new NotImplementedException();
    }

    @Override
    public int abilitiesPerSpecies() {
        return abilitiesPerSpecies;
    }

    @Override
    public int highestAbilityIndex() {
        throw new NotImplementedException();
    }

    @Override
    public String abilityName(int number) {
        throw new NotImplementedException();
    }

    @Override
    public Map<Integer, List<Integer>> getAbilityVariations() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getUselessAbilities() {
        throw new NotImplementedException();
    }

    @Override
    public boolean isTrainerPokemonAlwaysUseAbility1() {
        return trainerPokemonAlwaysUseAbility1;
    }

    @Override
    public boolean isTrainerPokemonUseBaseFormeAbilities() {
        return trainerPokemonUseBaseFormeAbilities;
    }

    @Override
    public boolean hasMegaEvolutions() {
        throw new NotImplementedException();
    }

    @Override
    public List<EncounterArea> getEncounters(boolean useTimeOfDay) {
        if(!useTimeOfDay) {
            throw new NotImplementedException();
        }

        if(testEncounters == null) {
            testEncounters = deepCopyEncounters(originalEncounters);
            testEncounters = deepCopyEncounters(originalEncounters);
        }

        return testEncounters;
    }

    @Override
    public List<EncounterArea> getSortedEncounters(boolean useTimeOfDay) {
        throw new NotImplementedException();
    }

    @Override
    public void setEncounters(boolean useTimeOfDay, List<EncounterArea> encounters) {
        testEncounters = encounters;
    }

    @Override
    public boolean hasTimeBasedEncounters() {
        return hasTimeBasedEncounters;
    }

    @Override
    public boolean hasWildAltFormes() {
        return hasWildAltFormes;
    }

    @Override
    public SpeciesSet getBannedForWildEncounters() {
        return originalBannedForWild;
        //TODO: ensure this works
    }

    @Override
    public void enableGuaranteedPokemonCatching() {
        throw new NotImplementedException();
    }

    @Override
    public List<Trainer> getTrainers() {
        if(testTrainers == null) {
            testTrainers = deepCopyTrainers(originalTrainers);
        }
        return testTrainers;
    }

    @Override
    public List<Integer> getMainPlaythroughTrainers() {
        return mainPlaythroughTrainers;
    }

    @Override
    public List<Integer> getEliteFourTrainers(boolean isChallengeMode) {
        if(isChallengeMode) {
            return challengeModeEliteFourTrainers;
        } else {
            return eliteFourTrainers;
        }
    }

    @Override
    public Map<String, Type> getGymAndEliteTypeThemes() {
        return gymAndEliteTypeThemes;
    }

    @Override
    public boolean canGiveCustomMovesetsToBossTrainers() {
        return canGiveCustomMovesetsToBossTrainers;
    }

    @Override
    public boolean canGiveCustomMovesetsToImportantTrainers() {
        return canGiveCustomMovesetsToImportantTrainers;
    }

    @Override
    public boolean canGiveCustomMovesetsToRegularTrainers() {
        return canGiveCustomMovesetsToRegularTrainers;
    }

    @Override
    public boolean canAddPokemonToBossTrainers() {
        return canAddPokemonToBossTrainers;
    }

    @Override
    public boolean canAddPokemonToImportantTrainers() {
        return canAddPokemonToImportantTrainers;
    }

    @Override
    public boolean canAddPokemonToRegularTrainers() {
        return canAddPokemonToRegularTrainers;
    }

    @Override
    public boolean canAddHeldItemsToBossTrainers() {
        throw new NotImplementedException();
    }

    @Override
    public boolean canAddHeldItemsToImportantTrainers() {
        throw new NotImplementedException();
    }

    @Override
    public boolean canAddHeldItemsToRegularTrainers() {
        throw new NotImplementedException();
    }

    @Override
    public int getHighestEvoLvl() {
        return highestEvoLvl;
    }

    @Override
    public List<Item> getSensibleHeldItemsFor(TrainerPokemon tp, boolean consumableOnly, List<Move> moves, int[] pokeMoves) {
        throw new NotImplementedException();
    }

    @Override
    public Set<Item> getAllConsumableHeldItems() {
        throw new NotImplementedException();
    }

    @Override
    public Set<Item> getAllHeldItems() {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasRivalFinalBattle() {
        throw new NotImplementedException();
    }

    @Override
    public void makeDoubleBattleModePossible() {
        //do nothing
    }

    @Override
    public boolean hasPhysicalSpecialSplit() {
        throw new NotImplementedException();
    }

    @Override
    public List<Move> getMoves() {
        if(testMoves == null) {
            testMoves = deepCopyMoves(originalMoves);
        }
        return testMoves;
    }

    @Override
    public int getMaxMoveNameLength() {
        return maxMoveNameLength;
    }

    @Override
    public Map<Integer, List<MoveLearnt>> getMovesLearnt() {
        if (testMovesLearnt == null) {
            testMovesLearnt = new HashMap<>();
            for (Integer pkNum : originalMovesLearnt.keySet()) {

                List<MoveLearnt> moveLearntsCopy = new ArrayList<>();
                for (MoveLearnt ml : originalMovesLearnt.get(pkNum)) {
                    moveLearntsCopy.add(new MoveLearnt(ml));
                }
                testMovesLearnt.put(pkNum, moveLearntsCopy);
            }
        }

        return testMovesLearnt;
    }

    @Override
    public void setMovesLearnt(Map<Integer, List<MoveLearnt>> movesets) {
        testMovesLearnt = movesets;
    }

    @Override
    public List<Integer> getMovesBannedFromLevelup() {
        throw new NotImplementedException();
    }

    @Override
    public Map<Integer, List<Integer>> getEggMoves() {
        if (testEggMoves == null) {
            testEggMoves = new HashMap<>();
            for (Map.Entry<Integer, List<Integer>> entry : originalEggMoves.entrySet()) {
                testEggMoves.put(entry.getKey(), new ArrayList<>(entry.getValue()));
            }
        }

        return testEggMoves;
    }

    @Override
    public void setEggMoves(Map<Integer, List<Integer>> eggMoves) {
        testEggMoves = eggMoves;
    }

    @Override
    public boolean supportsFourStartingMoves() {
        throw new NotImplementedException();
    }

    @Override
    public List<StaticEncounter> getStaticPokemon() {
        if(!canChangeStaticPokemon) {
            throw new UnsupportedOperationException("Base romHandler does not support changing statics!");
        }

        if(testStatics == null) {
            testStatics = deepCopyStatics(originalStatics);
        }
        return testStatics;
    }

    @Override
    public boolean setStaticPokemon(List<StaticEncounter> staticPokemon) {
        if(!canChangeStaticPokemon) {
            throw new UnsupportedOperationException("Base romHandler does not support changing statics!");
        }

        testStatics = staticPokemon;
        return true;
    }

    @Override
    public boolean canChangeStaticPokemon() {
        return canChangeStaticPokemon;
    }

    @Override
    public boolean hasStaticAltFormes() {
        return hasStaticAltFormes;
    }

    @Override
    public SpeciesSet getBannedForStaticPokemon() {
        return originalBannedForStatics;
        //TODO: verify this works
    }

    @Override
    public boolean forceSwapStaticMegaEvos() {
        //what... does this mean
        return forceSwapStaticMegaEvos;
    }

    @Override
    public boolean hasMainGameLegendaries() {
        return !mainGameLegendaries.isEmpty();
    }

    @Override
    public List<Integer> getMainGameLegendaries() {
        return mainGameLegendaries;
    }

    @Override
    public List<Integer> getSpecialMusicStatics() {
        throw new NotImplementedException();
    }

    @Override
    public void applyCorrectStaticMusic(Map<Integer, Integer> specialMusicStaticChanges) {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasStaticMusicFix() {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasTotemPokemon() {
        return hasTotemPokemon;
    }

    @Override
    public List<TotemPokemon> getTotemPokemon() {
        if(!hasTotemPokemon) {
            throw new UnsupportedOperationException("Base romHandler does not support Totem Pokemon!");
        }

        if(testTotems == null) {
            testTotems = deepCopyTotems(originalTotems);
        }
        return testTotems;
    }

    @Override
    public void setTotemPokemon(List<TotemPokemon> totemPokemon) {
        if(!hasTotemPokemon) {
            throw new UnsupportedOperationException("Base romHandler does not support Totem Pokemon!");
        }

        testTotems = totemPokemon;
    }

    @Override
    public List<Integer> getTMMoves() {
        if (testTMMoves == null) {
            testTMMoves = new ArrayList<>(originalTMMoves);
        }

        return testTMMoves;
    }

    @Override
    public List<Integer> getHMMoves() {
        return hmMoves;
    }

    @Override
    public void setTMMoves(List<Integer> moveIndexes) {
        testTMMoves = moveIndexes;
    }

    @Override
    public int getTMCount() {
        return originalTMMoves.size();
    }

    @Override
    public int getHMCount() {
        return hmMoves.size();
    }

    @Override
    public Map<Species, boolean[]> getTMHMCompatibility() {
        if (testTMHMCompatibility == null) {
            testTMHMCompatibility = new HashMap<>();
            for (Map.Entry<Species, boolean[]> entry : originalTMHMCompatibility.entrySet()) {
                testTMHMCompatibility.put(entry.getKey(), Arrays.copyOf(entry.getValue(), entry.getValue().length));
            }
        }

        return testTMHMCompatibility;
    }

    @Override
    public void setTMHMCompatibility(Map<Species, boolean[]> compatData) {
        testTMHMCompatibility = compatData;
    }

    @Override
    public boolean isTMsReusable() {
        return testIsTMsReusable;
    }

    @Override
    public boolean canTMsBeHeld() {
        return canTMsBeHeld;
    }

    @Override
    public boolean hasMoveTutors() {
        return hasMoveTutors;
    }

    @Override
    public List<Integer> getMoveTutorMoves() {
        if (testMoveTutorMoves == null) {
            testMoveTutorMoves = new ArrayList<>(originalMoveTutorMoves);
        }
        return testMoveTutorMoves;
    }

    @Override
    public void setMoveTutorMoves(List<Integer> moves) {
        testMoveTutorMoves = moves;
    }

    @Override
    public Map<Species, boolean[]> getMoveTutorCompatibility() {
        if (testMoveTutorCompatibility == null) {
            testMoveTutorCompatibility = new HashMap<>();
            for (Map.Entry<Species, boolean[]> entry : originalMoveTutorCompatibility.entrySet()) {
                testMoveTutorCompatibility.put(entry.getKey(), Arrays.copyOf(entry.getValue(), entry.getValue().length));
            }
        }

        return testMoveTutorCompatibility;
    }

    @Override
    public void setMoveTutorCompatibility(Map<Species, boolean[]> compatData) {
        testMoveTutorCompatibility = compatData;
    }

    @Override
    public boolean canChangeTrainerText() {
        throw new NotImplementedException();
    }

    @Override
    public TrainerNameMode trainerNameMode() {
        throw new NotImplementedException();
    }

    @Override
    public int maxTrainerNameLength() {
        throw new NotImplementedException();
    }

    @Override
    public int maxSumOfTrainerNameLengths() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getTCNameLengthsByTrainer() {
        throw new NotImplementedException();
    }

    @Override
    public boolean fixedTrainerClassNamesLength() {
        throw new NotImplementedException();
    }

    @Override
    public int maxTrainerClassNameLength() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getDoublesTrainerClasses() {
        throw new NotImplementedException();
    }

    @Override
    public Set<Item> getEvolutionItems() {
        return evolutionItems;
    }

    @Override
    public Set<Item> getXItems() {
        return xItems;
    }

    @Override
    public Set<Item> getMegaStones() {
        return uniqueNoSellItems;
    }

    @Override
    public Set<Item> getRegularShopItems() {
        return regularShopItems;
    }

    @Override
    public Set<Item> getOPShopItems() {
        return opShopItems;
    }

    @Override
    public List<Item> getItems() {
        return items;
    }

    @Override
    public Set<Item> getRequiredFieldTMs() {
        return requiredFieldTMs;
    }

    @Override
    public List<Item> getFieldItems() {
        if (testFieldItems == null) {
            testFieldItems = new ArrayList<>(originalFieldItems);
        }
        return testFieldItems;
    }

    @Override
    public void setFieldItems(List<Item> items) {
        for (int i = 0; i < originalFieldItems.size(); i++) {
            if (items.get(i).isTM() != originalFieldItems.get(i).isTM())
                throw new IllegalArgumentException("TM must replace TM and vice versa.");
        }
        testFieldItems = items;
    }

    @Override
    public boolean hasShopSupport() {
        return !originalShops.isEmpty();
    }

    @Override
    public List<Shop> getShops() {
        if (testShops == null) {
            testShops = new ArrayList<>();
            for (Shop shop : originalShops) {
                testShops.add(new Shop(shop));
            }
        }
        return testShops;
    }

    @Override
    public void setShops(List<Shop> shops) {
        testShops = shops;
    }

    @Override
    public List<Integer> getShopPrices() {
        throw new NotImplementedException();
    }

    @Override
    protected Map<Integer, Integer> getBalancedShopPrices() {
        throw new NotImplementedException();
    }

    @Override
    public void setShopPrices(List<Integer> prices) {
        throw new NotImplementedException();
    }

    @Override
    public List<PickupItem> getPickupItems() {
        if (testPickupItems == null) {
            testPickupItems = new ArrayList<>(originalPickupItems.size());
            for (PickupItem pi : originalPickupItems) {
                testPickupItems.add(new PickupItem(pi));
            }
        }
        return testPickupItems;
    }

    @Override
    public void setPickupItems(List<PickupItem> pickupItems) {
        testPickupItems = pickupItems;
    }

    @Override
    public List<InGameTrade> getInGameTrades() {
        throw new NotImplementedException();
    }

    @Override
    public void setInGameTrades(List<InGameTrade> trades) {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasDVs() {
        throw new NotImplementedException();
    }

    @Override
    public int maxTradeNicknameLength() {
        throw new NotImplementedException();
    }

    @Override
    public int maxTradeOTNameLength() {
        throw new NotImplementedException();
    }

    @Override
    public void removeImpossibleEvolutions(boolean changeMoveEvos, boolean useEstimatedLevels) {
        throw new NotImplementedException();
    }

    @Override
    public void condenseLevelEvolutions(int maxLevel) {
        throw new NotImplementedException();
    }

    @Override
    public void makeEvolutionsEasier(boolean changeWithOtherEvos, boolean useEstimatedLevels) {
        throw new NotImplementedException();
    }

    @Override
    public Map<Species, List<Evolution>> getPreImprovedEvolutions() {
        throw new NotImplementedException();
    }

    @Override
    public boolean altFormesCanHaveDifferentEvolutions() {
        return altFormesCanHaveDifferentEvolutions;
    }

    @Override
    public List<Integer> getGameBreakingMoves() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getIllegalMoves() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getFieldMoves() {
        throw new NotImplementedException();
    }

    @Override
    public List<Integer> getEarlyRequiredHMMoves() {
        throw new NotImplementedException();
    }

    @Override
    public boolean isYellow() {
        return isYellow;
    }

    @Override
    public boolean isORAS() {
        return isORAS;
    }

    @Override
    public boolean isUSUM() {
        return isUSUM;
    }

    @Override
    public boolean hasMultiplePlayerCharacters() {
        throw new NotImplementedException();
    }

    @Override
    public String getROMName() {
        throw new NotImplementedException();
    }

    @Override
    public String getROMCode() {
        throw new NotImplementedException();
        //What even is this...?
    }

    @Override
    public int getROMType() {
        return romType;
    }

    @Override
    public String getSupportLevel() {
        throw new NotImplementedException();
    }

    @Override
    public String getDefaultExtension() {
        throw new UnsupportedOperationException("File functions cannot be called in TestRomHandler");
    }

    @Override
    public int internalStringLength(String string) {
        throw new NotImplementedException();
    }

    @Override
    public boolean setIntroPokemon(Species pk) {
        throw new NotImplementedException();
    }

    @Override
    public int generationOfPokemon() {
        return generation;
    }

    @Override
    public int miscTweaksAvailable() {
        return miscTweaksAvailable;
    }

    @Override
    public void applyMiscTweak(MiscTweak tweak) {
        if ((miscTweaksAvailable & tweak.getValue()) > 0) {
            if (tweak == MiscTweak.REUSABLE_TMS) {
                testIsTMsReusable = true;
            } else {
                throw new UnsupportedOperationException("unimplemented");
            }
        }
    }

    @Override
    public boolean setCatchingTutorial(Species opponent, Species player) {
        throw new NotImplementedException();
    }

    @Override
    public void setPCPotionItem(Item item) {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasFunctionalFormes() {
        throw new NotImplementedException();
    }

    @Override
    public SpeciesSet getBannedFormesForTrainerPokemon() {
        if(testBannedForTrainers == null) {
            testBannedForTrainers = SpeciesSet.unmodifiable(copySpeciesSet(originalBannedForTrainers));
        }
        return testBannedForTrainers;
    }

    @Override
    public void loadPokemonPalettes() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void savePokemonPalettes() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean hasPokemonPaletteSupport() {
        return hasPokemonPaletteSupport;
    }

    @Override
    public boolean pokemonPaletteSupportIsPartial() {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasCustomPlayerGraphicsSupport() {
        throw new NotImplementedException();
    }

    @Override
    public void setCustomPlayerGraphics(CustomPlayerGraphics customPlayerGraphics) {
        throw new NotImplementedException();
    }

    @Override
    public boolean hasPokemonImageGetter() {
        throw new NotImplementedException();
    }

    @Override
    public PokemonImageGetter createPokemonImageGetter(Species pk) {
        throw new NotImplementedException();
    }

    @Override
    public String getPaletteFilesID() {
        if (paletteFilesID == null) {
            throw new UnsupportedOperationException();
        }
        return paletteFilesID;
    }

    @Override
    public List<BufferedImage> getAllPokemonImages() {
        throw new NotImplementedException();
    }

    @Override
    public TypeService getTypeService() {
        return new TypeService(this);
    }

    @Override
    public TypeTable getTypeTable() {
        return new TypeTable(testTypeTable != null ? testTypeTable : originalTypeTable);
    }

    @Override
    public void setTypeTable(TypeTable typeTable) {
        testTypeTable = typeTable;
    }

    @Override
    public boolean hasTypeEffectivenessSupport() {
        return hasTypeEffectivenessSupport;
    }
}
